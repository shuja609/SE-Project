<?php
	$con=mysqli_connect("localhost","root","","se") or die(mysql_error());

?>
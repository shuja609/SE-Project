<?php
	include("db.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="Width=device-width, initial-scale=1.0">
	<title>Loggined</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
	<h1> Welcome User</h1>
	<a href="login.php">Logout</a>
</body>
</html>
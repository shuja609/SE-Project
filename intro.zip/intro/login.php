<?php
  session_start();
  include("db.php");
  if($_SERVER['REQUEST_METHOD']=="POST")
  {
    $Aemail=$_POST['email'];
    $Apassword=$_POST['password']; 
    if(!empty($Aemail) && !empty($Apassword) && !is_numeric($Aemail))
    {
      $query="select * from form where email='$Aemail' limit 1";
      $result=mysqli_query($con,$query);
      if($result)
      {
        if($result && mysqli_num_rows($result)>0)
        {
          $user_data=mysqli_fetch_assoc($result);
          if($user_data['password']==$Apassword)
          {
            //echo"<Script type='text/javascript'>alert('Successfully Logined')</script>)";
            header("location:index.php");
            die;
          }
        }
      }
      echo"<Script type='text/javascript'>alert('Wrong Email or Password')</script>)";
    }
    else
    {
      echo"<Script type='text/javascript'>alert('Wrong Email or Password')</script>)";

    }
  }
?>


<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="Width=device-width, initial-scale=1.0">
  <title>Login  page</title>
  <link rel="stylesheet" type="text/css" href="index.css">
  <!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <div class="container">
    <div class="form">
      <img src="pic2.png" alt="tea cup" height="200" width="200">
      <h1 id="title">Login</h1>
      <h2>By Signing In You Are Agreeing <br>Our Terms And Policy</h2>
      <form method="POST">
           <h2>Don't have an account?<a href="register.php">click here</a></h2>
        <div class="input-group">
         
          <div class="input-field" >
            <input type="email" name="email" placeholder="Email" required>
          </div>
          <div class="input-field" >
            <input type="password" name="password" placeholder="Password" required>
          </div>
          <p>Forget Password<a href="desktop3.html">click here</a></p>
          <div class="btn-field">
            <input type="submit" name="" value="Submit">
          
        </div>
          <h2>Or Sign up with</h2>
        </div>
      <a href="https://en-gb.facebook.com/" class="fa fa-facebook"></a>
      <a href="https://twitter.com/login?lang=en-GB" class="fa fa-twitter"></a>
      <a href="https://accounts.google.com/ServiceLogin?elo=1" class="fa fa-google"></a>
      <a href="https://www.instagram.com/accounts/login/" class="fa fa-instagram"></a>
      </form>
      
    </div>
  </div>
 
</body>
</html>